package co.edu.uniandes.prodAndes.vos;

public class ProveedorValue {

}
