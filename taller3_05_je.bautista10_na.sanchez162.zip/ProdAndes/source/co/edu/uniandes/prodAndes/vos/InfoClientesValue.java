package co.edu.uniandes.prodAndes.vos;

import java.util.ArrayList;

public class InfoClientesValue {

private long idLegal;
	
	private long codigo; 
	
	private String nombreLegal;
	
	private String resgistroSINV;
	
	private long tipoIdLegal;
	
	private ArrayList<Pedido> pedidos;
}
